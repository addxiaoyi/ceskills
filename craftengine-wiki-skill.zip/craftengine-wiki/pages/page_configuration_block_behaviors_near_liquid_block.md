---
id: page:configuration_block_behaviors_near_liquid_block
type: Block
url: https://ce-pre.gtemc.cn/zh-Hans/configuration/block/behaviors/near_liquid_block
aliases: 邻液方块, configuration block behaviors near liquid block, 🤽 邻液方块, 示例
---

# 🤽 邻液方块

- 类型：Block
- 原文：https://ce-pre.gtemc.cn/zh-Hans/configuration/block/behaviors/near_liquid_block
- 连接数：0

## 摘要

本页总览 # 🤽 邻液方块 邻液方块必须放置在靠近水或熔岩的位置才能存活。与液面方块不同，它不要求液体必须是源方块——流动液体也有效。冰视为水源。 它检查方块周围的特定相对位置（通过 `positions` 配置）。若某个位置存在目标液体（或冰），且该位置上方没有任何流体，则该位置满足存活条件。 若启用 `stackable`，方块也可堆叠在同类型方块上存活。 模式说明堆叠模式（`stackable: true`）即使附近无指定的液体只要堆叠在同类型方块上即可存活非堆叠模式（`stackable: false`）至少需要在某个 `positions` 处有指定的液体 ## 示例​ `blocks: default:flame_cane: behavior: type: near_liquid_block liquid_type: lava # "water"、"lava" 或两者 ["water", "lava"]（默认为 ["water"]） stackable: true # 允许堆叠在同类型方块上（默认为 false） positions: # 检查液体的相对位置（必需） -

## YAML 片段

```yaml
blocks:  default:flame_cane:
    behavior:
      type: near_liquid_block      liquid_type: lava              # "water"、"lava" 或两者 ["water", "lava"]（默认为 ["water"]）      stackable: true                # 允许堆叠在同类型方块上（默认为 false）      positions:                     # 检查液体的相对位置（必需）
      - -1,-1,0
      - 1,-1,0
      - 0,-1,-1
      - 0,-1,1
```

## 相关页面

- （无）
