---
id: page:configuration_block_behaviors_bush_block
type: Block
url: https://ce-pre.gtemc.cn/zh-Hans/configuration/block/behaviors/bush_block
aliases: 灌木方块, configuration block behaviors bush block, 🪻 灌木方块, 示例
---

# 🪻 灌木方块

- 类型：Block
- 原文：https://ce-pre.gtemc.cn/zh-Hans/configuration/block/behaviors/bush_block
- 连接数：0

## 摘要

本页总览 # 🪻 灌木方块 灌木方块只能生长在特定的支撑方块上——类似花或树苗。若支撑方块被破坏或无效，方块即会破坏。 可选择堆叠：开启 `stackable` 后，多个同类型方块可互相堆叠，最多 `max_height` 层。堆叠时会计算下方连续的同类型方块数量，当达到最大高度时，将无法继续向上堆叠。 放置后会自动检查支撑方块。若 `delay` 设为正值，因[PP更新](https://zh.minecraft.wiki/w/%E6%96%B9%E5%9D%97%E6%9B%B4%E6%96%B0#PP%E6%9B%B4%E6%96%B0)触发的存活检查会延迟相应刻数执行，而非立即执行——适用于需要在短暂方块替换过程中存活的方块。 模式说明黑名单模式（`blacklist: true`）方块可生长在除了列表以外的任何方块上白名单模式（`blacklist: false`）方块只能生长在列表中的方块上 ## 示例​ `blocks: default:fairy_flower: behavior: type: bush_block blacklist: false # true =

## YAML 片段

```yaml
blocks:  default:fairy_flower:
    behavior:
      type: bush_block      blacklist: false                # true = 黑名单，false = 白名单      stackable: false                # 是否允许同类型方块向上堆叠      max_height: 0                   # 最大堆叠高度，仅在 stackable 为 true 时生效（需大于 1）      delay: 0                        # 检查延迟（刻），0 = 支撑无效时立即破坏      bottom_blocks:                  # 要检查的特定方块（可选）
      - custom:xxx
      - minecraft:stone
      bottom_block_tags:              # 要检查的方块标签（可选）
      - minecraft:dirt
      - minecraft:farmland
```

## 相关页面

- （无）
