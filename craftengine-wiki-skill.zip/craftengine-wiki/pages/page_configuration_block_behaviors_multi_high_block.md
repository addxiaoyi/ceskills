---
id: page:configuration_block_behaviors_multi_high_block
type: Block
url: https://ce-pre.gtemc.cn/zh-Hans/configuration/block/behaviors/multi_high_block
aliases: 多层方块, configuration block behaviors multi high block, 🏢 多层方块, 示例
---

# 🏢 多层方块

- 类型：Block
- 原文：https://ce-pre.gtemc.cn/zh-Hans/configuration/block/behaviors/multi_high_block
- 连接数：0

## 摘要

本页总览 # 🏢 多层方块 多层方块会根据指定的 `int` 属性自动生成一个垂直连续的多格结构。属性的取值范围决定结构的层数。 例如 `range: 0~2` 会生成三层结构： - `0`：底部 - `1`：中部 - `2`：顶部 放置时会自动在上方生成其余层级，并将每层的属性值设置为对应高度。 结构中的每一层都必须与其应连接的上一层或下一层保持连续。若某层检测到相邻层缺失、属性值不连续或不是同一种自定义方块，则该层会被移除，并通过[PP更新](https://zh.minecraft.wiki/w/%E6%96%B9%E5%9D%97%E6%9B%B4%E6%96%B0#PP%E6%9B%B4%E6%96%B0)使整个结构最终被移除。 当玩家破坏非底部部分时： - 使用正确工具：保持正常掉落逻辑； - 使用错误工具：底部会被一并移除且不会掉落； - 创造模式：底部会被一并移除且不会掉落。 放置时，所有需要占用的位置都必须可替换，并且结构顶部不能超过世界建筑高度上限。 属性名称属性类型是否必需自定义int是 ## 示例​ `blocks: default:multi_high_bl

## YAML 片段

```yaml
blocks:  default:multi_high_block:
    states:      properties:        height:                   # 声明一个自定义 int 属性
      type: int          default: 0          range: 0~2              # 0=底部，1=中部，2=顶部
    behavior:
      type: multi_high_block      property: height            # 用于控制高度的 int 属性名（必需）
```

## 相关页面

- （无）
