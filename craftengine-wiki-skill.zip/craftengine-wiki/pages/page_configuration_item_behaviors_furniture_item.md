---
id: page:configuration_item_behaviors_furniture_item
type: Item
url: https://ce-pre.gtemc.cn/zh-Hans/configuration/item/behaviors/furniture_item
aliases: 家具物品, configuration item behaviors furniture item, 🪑 家具物品, 放置规则
---

# 🪑 家具物品

- 类型：Item
- 原文：https://ce-pre.gtemc.cn/zh-Hans/configuration/item/behaviors/furniture_item
- 连接数：4

## 摘要

本页总览 # 🪑 家具物品 右键点击有效表面时放置家具。 `items: default:bench: behavior: type: furniture_item furniture: default:bench # 引用已有家具 ID rules: ground: rotation: four # any / four / eight / sixteen / north / east / west / south alignment: center # any / center / half / quarter / corner / center_quarter ignore_placer: false # 放置时忽略放置者的碰撞 ignore_entities: false # 放置时忽略实体碰撞` `furniture` 字段也支持内联定义——家具会以物品自身的 ID 注册： `items: default:bench: behavior: type: furniture_item rules: ground: rotation: four alignment: center

## YAML 片段

```yaml
items:  default:bench:
    behavior:
      type: furniture_item
furniture: default:bench          # 引用已有家具 ID      rules:        ground:          rotation: four                # any / four / eight / sixteen / north / east / west / south          alignment: center             # any / center / half / quarter / corner / center_quarter      ignore_placer: false              # 放置时忽略放置者的碰撞      ignore_entities: false            # 放置时忽略实体碰撞
```

```yaml
items:  default:bench:
    behavior:
      type: furniture_item      rules:        ground:          rotation: four          alignment: center
furniture:                        # 内联：定义一个新家具
    events:
      - template: default:rotatable_furniture_4
    settings:
      item: default:bench          hit_times: 3
      sounds:            break: minecraft:block.bamboo_wood.break            place: minecraft:block.bamboo_wood.place        variants:          ground:            loot_spawn_offset: 0.5,0.5,0            elements:
      - item: default:bench                display_transform: none                billboard: fixed                position: 0.5,0,0                translation: 0,0.5,0            hitboxes:
      - position: 0,0,0
      type: shulker
      seats:
      - 0,0,-0.1 0
      - 1,0,-0.1 0
    loot:          template: default:loot_table/furniture          arguments:
      item: default:bench
```

## 相关页面

- （无）
