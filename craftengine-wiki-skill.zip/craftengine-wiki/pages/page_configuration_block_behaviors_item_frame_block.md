---
id: page:configuration_block_behaviors_item_frame_block
type: Block
url: https://ce-pre.gtemc.cn/zh-Hans/configuration/block/behaviors/item_frame_block
aliases: 物品展示框方块, configuration block behaviors item frame block, 🖼️ 物品展示框方块, 示例
---

# 🖼️ 物品展示框方块

- 类型：Block
- 原文：https://ce-pre.gtemc.cn/zh-Hans/configuration/block/behaviors/item_frame_block
- 连接数：0

## 摘要

本页总览 # 🖼️ 物品展示框方块 物品展示框方块是原版物品展示框的高性能替代方案。用于存储和展示单个物品。 - 右键手持物品放入。 - 空主手右键取出物品。 - 潜行 + 右键旋转展示的物品（共 8 个方向）。 比较器信号等于 `rotation + 1`（有物品时），空时为 `0`——刚放置未旋转的展示框发出信号 1。 特别感谢：该功能由 [SIMMC 服务器](https://simmc.cn/)赞助 [jhqwqmc](https://github.com/jhqwqmc/) 开发。 属性名称属性类型是否必需facingdirection是 ## 示例​ `blocks: default:item_frame_block: behavior: type: item_frame_block position: 0,0,0 # 展示物品的位置偏移（默认为 0,0,0） glow: false # 是否发光 invisible: false # 是否隐藏展示框边框 render_map_item: true # 是否启用静态地图渲染（默认为 true，有少量性能开销） data_k

## YAML 片段

```yaml
blocks:  default:item_frame_block:
    behavior:
      type: item_frame_block      position: 0,0,0                    # 展示物品的位置偏移（默认为 0,0,0）      glow: false                        # 是否发光      invisible: false                   # 是否隐藏展示框边框      render_map_item: true              # 是否启用静态地图渲染（默认为 true，有少量性能开销）      data_key: "craftengine:item_frame" # 持久化数据的 NBT 键（默认为 "craftengine:item_frame"）
      sounds:        put: entity.item_frame.add_item        # 放入时播放的音效（可选）        take: entity.item_frame.remove_item    # 取出时播放的音效（可选）        rotate: entity.item_frame.rotate_item  # 旋转时播放的音效（可选）
```

## 相关页面

- （无）
