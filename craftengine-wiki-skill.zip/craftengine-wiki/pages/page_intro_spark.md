---
id: page:intro_spark
type: Config
url: https://ce-pre.gtemc.cn/zh-Hans/intro/spark
aliases: Spark, intro spark, ⚡ Spark, 主线程性能分析
---

# ⚡ Spark

- 类型：Config
- 原文：https://ce-pre.gtemc.cn/zh-Hans/intro/spark
- 连接数：0

## 摘要

本页总览 # ⚡ Spark ## 主线程性能分析​ Spark 所显示的数据有时并不能完全反映真实情况。你可能会观察到一些归属于 CraftEngine 的性能开销，实际上并非由插件本身直接造成。这一点不应归咎于 Spark，毕竟这和其底层工作机制有关。 在进行主线程性能分析时，如果您遇到疑似与 CraftEngine 相关的问题，建议先排除以下常见干扰项（下图取样于 500 名真实玩家同时在线的服务器环境）： - 以 Injected 开头的类（图中红色标记部分） 这些类是 CraftEngine 为优化特定效果而对服务端原有类进行的注入。因此，部分原本属于服务端的性能消耗，在分析中会被计入 CraftEngine。 - API 调用（图中绿色标记部分） 当您通过 CraftEngine API 监听事件或构建物品时，相应耗时在性能分析中也会被归入 CraftEngine 名下。

## YAML 片段

```yaml
# 本页没有抽出 YAML，请打开原文 URL
```

## 相关页面

- （无）
